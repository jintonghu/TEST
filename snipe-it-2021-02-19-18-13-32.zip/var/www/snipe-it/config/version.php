<?php
return array (
  'app_version' => 'v4.9.1',
  'full_app_version' => 'v4.9.1 - build 4341-ga0f7fdc57',
  'build_version' => '4341',
  'prerelease_version' => '',
  'hash_version' => 'ga0f7fdc57',
  'full_hash' => 'v4.9.1-127-ga0f7fdc57',
  'branch' => 'master',
);